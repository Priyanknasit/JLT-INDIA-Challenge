var tests = [
  {
    name: 'help',
    jsonform: {
      form: [
        {
          type: 'help',
          helpvalue: 'Yell <strong>help!</strong> for help'
        }
      ]
    }
  }
];
